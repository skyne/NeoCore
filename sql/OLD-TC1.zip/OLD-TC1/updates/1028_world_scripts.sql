UPDATE `creature_template` SET `ScriptName`='boss_the_black_stalker' WHERE `entry`='17882';

