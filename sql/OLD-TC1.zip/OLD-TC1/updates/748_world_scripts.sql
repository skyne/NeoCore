update creature_template set scriptname='npc_infused_crystal', flags_extra=0 where entry=16364;
delete from creature where id=17086;

