UPDATE creature_template SET Scriptname='npc_ranger_lilatha' WHERE entry=16295;

