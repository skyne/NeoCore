update creature_template set flags_extra = 128 where entry = 12999;

