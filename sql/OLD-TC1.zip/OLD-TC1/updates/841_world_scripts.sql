update creature_template set scriptname='npc_greengill_slave' where entry=25084;

