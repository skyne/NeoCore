update creature_template set scriptname='npc_professor_dabiri' where entry=20907;

