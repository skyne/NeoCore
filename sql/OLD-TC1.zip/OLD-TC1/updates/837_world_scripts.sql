update creature_template set scriptname='npc_khadgar' where entry=18166;

