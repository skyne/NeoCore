UPDATE `gameobject_template` SET `faction`=1375 WHERE `entry` IN (184203, 184204, 184205);
UPDATE `gameobject_template` SET `Scriptname`='go_bridge_console' WHERE entry=184568;

