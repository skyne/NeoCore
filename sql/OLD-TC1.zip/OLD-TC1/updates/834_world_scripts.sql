UPDATE `creature_template` SET `ScriptName`='npc_ishanah' WHERE `entry`=18538;

