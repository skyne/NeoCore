DELETE FROM `spell_script_target` WHERE `entry` IN (34186, 42492, 33831, 5628, 45109, 45149);
INSERT INTO `spell_script_target` VALUES (34186, 1, 16938);
INSERT INTO `spell_script_target` VALUES (42492, 1, 0);
INSERT INTO `spell_script_target` VALUES (33831, 1, 0);
INSERT INTO `spell_script_target` VALUES (5628, 1, 2011);
INSERT INTO `spell_script_target` VALUES (5628, 1, 2012);
INSERT INTO `spell_script_target` VALUES (5628, 1, 2013);
INSERT INTO `spell_script_target` VALUES (5628, 1, 2014);
INSERT INTO `spell_script_target` VALUES (45109, 1, 25084);
INSERT INTO `spell_script_target` VALUES (45149, 0, 300154);

