update creature_template set scriptname='npc_deathstalker_erland' where entry=1978;

