UPDATE `spell_proc_event` SET `procFlags` = '8396800' WHERE `entry` =14774;
UPDATE `spell_proc_event` SET `procFlags` = '8396800' WHERE `entry` =14531;

