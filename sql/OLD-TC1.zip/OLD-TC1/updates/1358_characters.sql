ALTER TABLE `gm_tickets` ADD COLUMN `createtime` int(10) NOT NULL after `message`;
