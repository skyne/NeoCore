ALTER TABLE `gm_tickets` CHANGE `closed` `closed` int(10) NOT NULL default '0';

