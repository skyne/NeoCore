update creature_template set scriptname = 'npc_enraged_spirit' where entry in (21050, 21061, 21060, 21059);

