DELETE FROM `spell_proc_event` WHERE `entry` IN (42083, 33727, 33754, 33755, 33756, 8516, 10608, 10610, 25583, 25584);
INSERT INTO `spell_proc_event` VALUES ('42083', '0', '0', '0', '0', '2', '0', '0', '0');
INSERT INTO `spell_proc_event` VALUES ('33727', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('33754', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('33755', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('33756', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('8516', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('10608', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('10610', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('25583', '0', '0', '0', '0', '0', '0', '0', '3');
INSERT INTO `spell_proc_event` VALUES ('25584', '0', '0', '0', '0', '0', '0', '0', '3');

