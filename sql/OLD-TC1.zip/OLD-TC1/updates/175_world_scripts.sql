UPDATE `creature_template` SET `ScriptName`='npc_defias_traitor' WHERE `entry`='467';

