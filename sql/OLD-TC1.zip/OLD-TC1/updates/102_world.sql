ALTER TABLE `quest_template`
    ADD `RewHonorableKills` mediumint(9) unsigned NOT NULL default '0' AFTER `RewRepValue5`;

