update creature_template set scriptname='npc_kaya_flathoof' where entry=11856;

