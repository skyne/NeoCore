update creature_template set scriptname='npc_earthmender_wilda' where entry=21027;

