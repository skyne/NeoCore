UPDATE `creature_template` SET `ScriptName` = 'npc_ruul_snowhoof' WHERE `entry` = 12818;

