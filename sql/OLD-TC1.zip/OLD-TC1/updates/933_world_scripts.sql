update creature_template set scriptname='npc_snake_trap_serpents' where entry in (19921, 19833);

