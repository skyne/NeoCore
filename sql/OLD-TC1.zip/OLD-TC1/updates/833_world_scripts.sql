update creature_template set scriptname='npc_dirty_larry', unit_flags=0, flags_extra=0 where entry=19720;
update creature_template set unit_flags=0, flags_extra=0 where entry in (19726, 19725);

