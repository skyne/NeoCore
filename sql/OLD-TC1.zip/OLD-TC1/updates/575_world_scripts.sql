UPDATE `item_template` SET `ScriptName` = "item_only_for_flight" WHERE `entry` IN (34475, 34489, 24538);

