ALTER TABLE `gm_tickets` CHANGE `guid` `guid` int(10) NOT NULL AUTO_INCREMENT;
ALTER TABLE `gm_tickets` CHANGE `closed` `closed` int(10) NOT NULL;

