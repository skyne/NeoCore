delete from `spell_linked_spell` where `spell_trigger` in ('15237','15430','15431','27799','27800','27801','25331');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('15237','23455','0','Holy Nova (rank1)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('15430','23458','0','Holy Nova (rank2)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('15431','23459','0','Holy Nova (rank3)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('27799','27803','0','Holy Nova (rank4)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('27800','27804','0','Holy Nova (rank5)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('27801','27805','0','Holy Nova (rank6)');
insert into `spell_linked_spell` (`spell_trigger`, `spell_effect`, `type`, `comment`) values('25331','25329','0','Holy Nova (rank7)');

