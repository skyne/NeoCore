UPDATE `gameobject_template` SET `ScriptName` = 'go_mausoleum_trigger' WHERE `entry` = 104593;
UPDATE `gameobject_template` SET `ScriptName` = 'go_mausoleum_door' WHERE `entry` = 176594;

