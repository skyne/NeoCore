INSERT INTO `spell_script_target` VALUES ('30531', '1', '17256');
INSERT INTO `spell_script_target` VALUES ('41455', '1', '22949');
INSERT INTO `spell_script_target` VALUES ('41455', '1', '22950');
INSERT INTO `spell_script_target` VALUES ('41455', '1', '22951');
INSERT INTO `spell_script_target` VALUES ('41455', '1', '22952');
INSERT INTO `spell_script_target` VALUES ('42471', '1', '23817');
INSERT INTO `spell_script_target` VALUES ('43734', '1', '23817');
INSERT INTO `spell_script_target` VALUES ('42631', '1', '23920');

