UPDATE `gameobject_template` SET `scriptname`='go_skull_pile' WHERE `entry`=185913;
