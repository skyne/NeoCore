update creature_template set scriptname = 'npc_plains_vision' where entry = 2983;

