ALTER TABLE gm_tickets ADD `comment` text(0) NOT NULL;

