ALTER TABLE version
   ADD `core_revision` BIGINT UNSIGNED AFTER `core_version`;

