UPDATE `creature_template` SET `ScriptName` = 'npc_twiggy_flathead' WHERE `entry` =6248;

