insert into `command` (`name`, `security`, `help`) values('go ticket','1','Syntax: .go ticket #ticketid\r\nTeleports the user to the location where $ticketid was created.');
