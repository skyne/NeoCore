update creature_template set scriptname='npc_apprentice_mirveda' where entry=15402;

