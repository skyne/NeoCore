update creature_template set scriptname = 'npc_plucky' where entry in (6626);

