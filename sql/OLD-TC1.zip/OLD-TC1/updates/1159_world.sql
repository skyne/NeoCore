DELETE from `spell_affect` where entry=16999;
DELETE from `spell_affect` where entry=16998;
INSERT INTO `spell_affect` VALUES (16998, 0, 0x40000001000);
INSERT INTO `spell_affect` VALUES (16998, 1, 0x40000001000);
INSERT INTO `spell_affect` VALUES (16998, 2, 0x40000001000);
INSERT INTO `spell_affect` VALUES (16999, 0, 0x40000001000);
INSERT INTO `spell_affect` VALUES (16999, 1, 0x40000001000);
INSERT INTO `spell_affect` VALUES (16999, 2, 0x40000001000);


