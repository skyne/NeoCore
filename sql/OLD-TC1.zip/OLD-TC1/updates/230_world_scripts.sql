update gameobject_template set scriptname = 'go_gilded_brazier' where entry = 181956;

