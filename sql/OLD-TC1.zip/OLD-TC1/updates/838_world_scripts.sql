delete from spell_script_target where entry=42222;
insert into `spell_script_target` values
('42222','1','23616');
update `creature_template` set `scriptname`='npc_kyle_frenzied' where `entry`='23616';

