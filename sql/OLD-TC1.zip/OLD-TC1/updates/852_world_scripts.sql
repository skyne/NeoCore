update creature_template set scriptname='mob_nestlewood_owlkin' where entry=16518;
update item_template set scriptname='item_inoculating_crystal' where entry=22962;

