ALTER TABLE `account`
  CHANGE COLUMN  `email` `email` text;

