update quest_template set specialflags=2 where entry=665;
update creature_template set scriptname='npc_professor_phizzlethorpe' where entry=2768;

