UPDATE `gameobject_template` SET `ScriptName` = 'go_jump_a_tron' WHERE `entry` = 183146;
