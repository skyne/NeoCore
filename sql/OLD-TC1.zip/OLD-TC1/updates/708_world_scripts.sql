UPDATE `creature_template` SET `ScriptName` = 'boss_shirrak_the_dead_watcher' WHERE `entry` = '18371';
UPDATE `creature_template` SET `ScriptName` = 'mob_focus_fire', `unit_flags` = '33554434' WHERE `entry` = '18374';

