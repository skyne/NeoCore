ALTER TABLE gm_tickets ADD `name` varchar(15) NOT NULL AFTER `playerGuid`;

