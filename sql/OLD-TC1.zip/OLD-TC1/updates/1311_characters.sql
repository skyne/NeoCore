DROP TABLE IF EXISTS `has_logged_in_before`;
