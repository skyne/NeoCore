DELETE FROM trinity_string where entry IN (10056, 10057);
INSERT INTO trinity_string (entry, content_default) VALUES
(10056, 'You must be a member of the Horde to enter the Hall of Legends.'),
(10057, 'You must be a member of the Alliance to enter the Champion\'s Hall.');

