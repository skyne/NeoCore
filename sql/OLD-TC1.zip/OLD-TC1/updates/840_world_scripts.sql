UPDATE `creature_template` SET `spell1` = 0, `flags_extra` = 0, `ScriptName` = 'npc_volcano' WHERE `entry` = 23085;

