DELETE FROM `spell_script_target` WHERE entry IN (33655, 33633, 44374);
INSERT INTO `spell_script_target` VALUES
(33655,0,183350),
(33633,0,183351),
(44374,1,24722);

