update creature_template set scriptname='npc_isla_starmane' where entry=18760;

