UPDATE `trinity_string` SET `content_default`='Ticket %d is already assigned.' WHERE (`entry`='2008');

