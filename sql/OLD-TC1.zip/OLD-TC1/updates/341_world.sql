TRUNCATE  TABLE playercreateinfo_item;

