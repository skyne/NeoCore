DELETE FROM trinity_string WHERE entry IN (453);

