UPDATE creature_template SET ScriptName = 'npc_bessy' WHERE entry = 20415;

