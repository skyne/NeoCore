DELETE FROM `spell_script_target` WHERE `entry` in (30659);
INSERT INTO `spell_script_target` VALUES (30659, 1, 17281);


