update creature_template set scriptname='npc_wizzlecrank_shredder' where entry=3439;

