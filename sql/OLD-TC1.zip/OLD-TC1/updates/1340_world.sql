DELETE FROM `spell_affect` WHERE `entry`='12472' AND `effectId`='1';
INSERT INTO `spell_affect` VALUES ('12472', '1', "18446744073709551615");
