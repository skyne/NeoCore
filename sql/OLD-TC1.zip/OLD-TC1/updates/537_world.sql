-- Removing the now unused creature_movement table
DROP TABLE IF EXISTS `creature_movement`;

