DELETE FROM spell_proc_event where entry IN (31124, 31126);
INSERT INTO spell_proc_event () VALUES
(31124, 0, 8, 553648142, 0, 0, 0, 0, 0),
(31126, 0, 8, 553648142, 0, 0, 0, 0, 0);
