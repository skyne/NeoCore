UPDATE `gameobject_template` SET `scriptname` = 'go_sacred_fire_of_life' WHERE `entry` = 175944;
