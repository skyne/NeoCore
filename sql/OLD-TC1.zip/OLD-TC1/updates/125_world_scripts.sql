update creature_template set speed='0.01', scriptname='mob_toxic_sporebat' WHERE entry=22140;
update creature_template SET scriptname='npc_overlord_morghor' WHERE entry=23139;
update creature_template SET scriptname='npc_lord_illidan_stormrage' WHERE entry=22083;
update creature_template SET scriptname='npc_yarzill_the_merc' WHERE entry=23141;
update quest_template SET StartScript=0 WHERE entry=11108;

