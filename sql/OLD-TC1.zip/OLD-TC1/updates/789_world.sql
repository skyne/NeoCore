ALTER TABLE eventai_texts DROP COLUMN emote;

