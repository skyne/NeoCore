UPDATE `spell_proc_event` SET `SchoolMask` = '1' WHERE `entry` = '41434';

