DELETE FROM `spell_proc_event` WHERE `entry` = 36070;
INSERT INTO `spell_proc_event` (`entry`, `SchoolMask`, `SpellFamilyName`, `SpellFamilyMask`, `procFlags`, `procEx`, `ppmRate`, `CustomChance`, `Cooldown`) VALUES
(36070, 0x00, 0, 0x00000000, 0x00000008, 0x00000000, 0.000000, 0.000000, 0);

