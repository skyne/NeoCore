UPDATE `item_template` SET `ScriptName`='item_arcane_charges' WHERE `entry`='34475';
UPDATE gameobject_template SET faction = 14 WHERE entry = 185134;

